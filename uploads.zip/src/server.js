const http = require('http');
const app = require('./app');
const logger = require('./utils/logger');
const db = require('./config/database');

// Get port from environment
const PORT = process.env.PORT || 5000;

// Create HTTP server
const server = http.createServer(app);

// Socket.io setup (optional - for real-time messaging)
const io = require('socket.io')(server, {
  cors: {
    origin: '*', // Allow all origins for development (mobile app testing)
    credentials: true,
  },
});

// Socket.io connection handling
io.on('connection', (socket) => {
  logger.info(`Socket connected: ${socket.id}`);

  // Join conversation room
  socket.on('join_conversation', (conversationId) => {
    socket.join(`conversation_${conversationId}`);
    logger.info(`Socket ${socket.id} joined conversation ${conversationId}`);
  });

  // Leave conversation room
  socket.on('leave_conversation', (conversationId) => {
    socket.leave(`conversation_${conversationId}`);
    logger.info(`Socket ${socket.id} left conversation ${conversationId}`);
  });

  // Handle new message (real-time)
  socket.on('send_message', (data) => {
    const { conversationId, message } = data;
    io.to(`conversation_${conversationId}`).emit('new_message', message);
  });

  // Handle typing indicator
  socket.on('typing', (data) => {
    const { conversationId, userId, isTyping } = data;
    socket.to(`conversation_${conversationId}`).emit('user_typing', {
      userId,
      isTyping,
    });
  });

  // Handle disconnect
  socket.on('disconnect', () => {
    logger.info(`Socket disconnected: ${socket.id}`);
  });
});

// Make io accessible to controllers (for emitting events)
app.set('io', io);

// Start server
async function startServer() {
  try {
    // Database connection is tested in database.js during initialization
    // No need to manually connect with mysql2 pool

    // Start listening on all network interfaces (0.0.0.0)
    server.listen(PORT, '0.0.0.0', () => {
      logger.info(`✓ Server running on port ${PORT}`);
      logger.info(`✓ Environment: ${process.env.NODE_ENV || 'development'}`);
      logger.info(`✓ API URL: http://localhost:${PORT}${process.env.API_PREFIX || '/api'}`);
      logger.info(`✓ Network URL: http://192.168.0.17:${PORT}${process.env.API_PREFIX || '/api'}`);
      logger.info(`✓ Mobile App: Use http://192.168.0.17:${PORT} in your app config`);
    });
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM signal received: closing HTTP server');
  server.close(async () => {
    logger.info('HTTP server closed');
    await db.end();
    logger.info('Database connection closed');
    process.exit(0);
  });
});

process.on('SIGINT', async () => {
  logger.info('SIGINT signal received: closing HTTP server');
  server.close(async () => {
    logger.info('HTTP server closed');
    await db.end();
    logger.info('Database connection closed');
    process.exit(0);
  });
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  logger.error('Unhandled Promise Rejection:', err);
});

// Start the server
startServer();

module.exports = server;
